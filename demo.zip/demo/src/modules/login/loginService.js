app.factory('loginServices',['$http','appSetting','$window',function($http,$window,appSetting){
return {
    login : function(user) {
        console.log(user);
        var promise = $http.post(appSetting.API_URL,user).success(function(response){
            return promise;
        }).error(function(err){
            return promise
        });
        return promise;
    }
}
}]);