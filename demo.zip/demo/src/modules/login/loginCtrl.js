'use strict';
app.controller('loginCtrl',['$scope','$window','loginServices',function($scope,$window,loginServices){
    $scope.login = function(user){
        console.log(user);
        loginServices.login(user).success(function(response){
            alert("successfull");
        }).error(function(err){
            alert("failed");
        });
    }
    
}]);