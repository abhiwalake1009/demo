'use strict';
var app = angular.module("myDemo", ['ui.router']);

app.config(['$stateProvider','$urlRouterProvider', function($stateProvider, $urlRouterProvider){

    $urlRouterProvider.otherwise('/login');

    $stateProvider
        .state('login',{
            url : '/login',
            templateUrl : 'src/modules/login/login.html',
            controller:'loginCtrl'
        });

        // to add state remove ";" and .state('stateName',{ url: 'link will be shown in browser', templateUrl: 'path to the html for your design', controller:'respective controller name'})
}]);

app.constant('appSetting',{
    API_URl : 'common url for http calls',//add the server side url for rest calls. Use this is service file. good practice to use this in service only.
                                            // to get this in service file inject 'appSetting' and user 'appSetting.API_URL'
     
});